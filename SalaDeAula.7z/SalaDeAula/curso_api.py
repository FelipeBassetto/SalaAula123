from flask import Blueprint, jsonify, request
from services.cursos_service import cursos_db, \
    listar as service_listar, \
    localiza as service_localiza, \
    novo as service_novo, \
    remover as service_remover, \
    atualiza as service_atualiza

curso_app = Blueprint('curso_app', __name__, template_folder='templates')

@curso_app.route('/curso', methods=['GET'])
def listar():
    cur_list = service_listar()
    return jsonify(list(map(lambda pr: pr.__dict__(), cur_list)))

@curso_app.route('/curso/<int:id_curso>', methods=['GET'])
def localiza(id_curso):
    cur = service_localiza(id_curso)
    if(cur != None):
        return jsonify(cur.__dict__())
    return '', 404

@curso_app.route('/curso', methods=['POST'])
def novo():
    novo_curso = request.get_json()
    cur_list = service_novo(novo_curso)
    print('exibe com list comprehensions')
    return jsonify([cur.__dict__() for cur in cur_list])

@curso_app.route('/curso/<int:id_curso>', methods=['DELETE'])
def remover(id_curso):
    removido = service_remover(id_curso)
    if removido != None:
        return jsonify(removido.__dict__())
    return '', 404

@curso_app.route('/curso/<int:id_curso>', methods=['PUT'])
def atualiza(id_curso):
    curso_data = request.get_json()
    removido = service_atualiza(id_curso, curso_data)
    if removido != None:
        return jsonify(removido.__dict__())
    return '', 404