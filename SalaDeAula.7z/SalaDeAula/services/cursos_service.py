from model.curso import Curso
from infra.curso_log import CursoLog

cursos_db = []

def listar():
    return cursos_db

def localiza(id_curso):
    for p in cursos_db:
        if p.id_curso == id_curso:
            return p
    return None

def novo(curso_data):
    cursos_db.append(Professor.cria(curso_data))
    return cursos_db

def remover(id_curso):
    index = 0
    for p in cursos_db:
        if p.id == id_curso:
            log = CursoLog(p)
            del cursos_db[index]
            log.atualiza(p)
            p.finaliza_e_imprime()
            return p
        index = index + 1
    return None

def atualiza(id_curso, curso_data):
    index = 0
    for p in professores_db:
        if p.id_curso == id_curso:
            log = ProfessorLog(p)
            p.atualizar(curso_data)
            log.atualiza(p)
            log.finaliza_e_imprime()
            return p
        index = index + 1
    return None