from model.professor import Professor
from infra.solocitacaomatricula_log import SolicitacaoMatriculaLog

solic_db = []

def listar():
    return solic_db

def localiza(matricula):
    for p in solic_db:
        if p.matricula == matricula:
            return p
    return None

def novo(solic_data):
    solic_db.append(Professor.cria(solic_data))
    return solic_db

def remover(matricula):
    index = 0
    for p in solic_db:
        if p.id == matricula:
            log = ProfessorLog(p)
            del solic_db[index]
            log.atualiza(p)
            p.finaliza_e_imprime()
            return p
        index = index + 1
    return None

def atualiza(matricula, solic_data):
    index = 0
    for p in solic_db:
        if p.matricula == matricula:
            log = ProfessorLog(p)
            p.atualizar(solic_data)
            log.atualiza(p)
            log.finaliza_e_imprime()
            return p
        index = index + 1
    return None