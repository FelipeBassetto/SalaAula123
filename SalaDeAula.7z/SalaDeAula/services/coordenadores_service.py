from model.coordenador import Coordenador
from infra.coordenador_log import CoordenadorLog

coordenadores_db = []

def listar():
    return coordenadores_db

def localiza(id_co):
    for p in coordenadores_db:
        if p.id_co == id_co:
            return p
    return None

def novo(coordenador_data):
    coordenadores_db.append(Coordenador.cria(coordenador_data))
    return coordenadores_db

def remover(id_co):
    index = 0
    for p in coordenadores_db:
        if p.id == id_co:
            log = CoordenadorLog(p)
            del coordenadores_db[index]
            log.atualiza(p)
            p.finaliza_e_imprime()
            return p
        index = index + 1
    return None

def atualiza(id_co, coordenador_data):
    index = 0
    for p in coordenador_data:
        if p.id == id_co:
            log = CoordenadorLog(p)
            p.atualizar(coordenador_data)
            log.atualiza(p)
            log.finaliza_e_imprime()
            return p
        index = index + 1
    return None