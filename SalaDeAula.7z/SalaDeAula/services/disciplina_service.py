from model.disciplina import Disciplina
from infra.disciplina_log import DisciplinaLog

disciplinas_db = []

def listar():
    return disciplinas_db

def localiza(id_disciplina):
    for p in disciplinas_db:
        if p.id_disciplina == id_disciplina:
            return p
    return None

def novo(disciplina_data):
    disciplinas_db.append(Disciplina.cria(disciplina_data))
    return disciplinas_db

def remover(id_disciplina):
    index = 0
    for p in disciplinas_db:
        if p.id == id_disciplina:
            log = DisciplinaLog(p)
            del disciplinas_db[index]
            log.atualiza(p)
            p.finaliza_e_imprime()
            return p
        index = index + 1
    return None

def atualiza(id_disciplina, disciplina_data):
    index = 0
    for p in disciplinas_db:
        if p.id_disciplina == id_disciplina:
            log = DisciplinaLog(p)
            p.atualizar(disciplina_data)
            log.atualiza(p)
            log.finaliza_e_imprime()
            return p
        index = index + 1
    return None