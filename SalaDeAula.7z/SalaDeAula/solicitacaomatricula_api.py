from flask import Blueprint, jsonify, request
from services.solicitacaomatricua_service import solic_db, \
    listar as service_listar, \
    localiza as service_localiza, \
    novo as service_novo, \
    remover as service_remover, \
    atualiza as service_atualiza


solicitacaomatricula_app = Blueprint('solicitacaomatricula_app', __name__, template_folder='templates')

@solicitacaomatricula_app.route('/solicitacaomatricula', methods=['GET'])
def listar():
    pr_list = service_listar()
    return jsonify(list(map(lambda pr: pr.__dict__(), pr_list)))

@solicitacaomatricula_app.route('/disciplinsofertada/<int:id_solicitacaomatricula>', methods=['GET'])
def localiza(id_solicitacaomatricula):
    p = service_localiza(id_solicitacaomatricula)
    if(p != None):
        return jsonify(p.__dict__())
    return '', 404

@solicitacaomatricula_app.route('/solicitacaomatricula', methods=['POST'])
def novo():
    nova_solic = request.get_json()
    pr_list = service_novo(nova_solic)
    print('exibe com list comprehensions')
    return jsonify([pr.__dict__() for pr in pr_list])

@solicitacaomatricula_app.route('/solicitacaomatricula/<int:id_solicitacaomatricula>', methods=['DELETE'])
def remover(id_disciplina):
    removido = service_remover(matricula)
    if removido != None:
        return jsonify(removido.__dict__())
    return '', 404


@solicitacaomatricula_app.route('/solicitacaomatricula/<int:id_solicitacaomatricula>', methods=['PUT'])
def atualiza(id_solicitacaomatricula):
    solic_data = request.get_json()
    removido = service_atualiza(id_solicitacaomatricula, solic_data)
    if removido != None:
        return jsonify(removido.__dict__())
    return '', 404