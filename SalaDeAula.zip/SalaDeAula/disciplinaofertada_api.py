from flask import Blueprint, jsonify, request
from services.disciplinaofertada_service import DisciplinaOfertada_db, \
    listar as service_listar, \
    localiza as service_localiza, \
    novo as service_novo, \
    remover as service_remover, \
    atualiza as service_atualiza


disciplinaofertada_app = Blueprint('disciplinaofertada_app', __name__, template_folder='templates')

@disciplinaofertada_app.route('/disciplinaofertada', methods=['GET'])
def listar():
    disco_list = service_listar()
    return jsonify(list(map(lambda disco: disco.__dict__(), disco_list)))

@disciplinaofertada_app.route('/disciplinsofertada/<int:id_disciplinaofertada>', methods=['GET'])
def localiza(id_disciplinaofertada):
    p = service_localiza(id_disciplinaofertada)
    if(p != None):
        return jsonify(p.__dict__())
    return '', 404

@disciplinaofertada_app.route('/disciplinaofertada', methods=['POST'])
def novo():
    nova_disciplinaofertada = request.get_json()
    disco_list = service_novo(nova_disciplinaofertada)
    print('exibe com list comprehensions')
    return jsonify([disco.__dict__() for disco in disco_list])


@disciplinaofertada_app.route('/disciplinaofertada/<int:id_disciplinaofertada>', methods=['DELETE'])
def remover(id_disciplinaofertada):
    removido = service_remover(id_disciplinaofertada)
    if removido != None:
        return jsonify(removido.__dict__())
    return '', 404


@disciplinaofertada_app.route('/disciplinaofertada/<int:id_disciplinaofertada>', methods=['PUT'])
def atualiza(id_disciplinaofertada):
    disco_data = request.get_json()
    removido = service_atualiza(id_disciplinaofertada, disco_data)
    if removido != None:
        return jsonify(removido.__dict__())
    return '', 404