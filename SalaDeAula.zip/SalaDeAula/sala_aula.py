from flask import Flask, jsonify, request
from alunos_api import alunos_app
from professores_api import professores_app
from coordenador_api import coordenador_app
from curso_api import curso_app
from disciplina_api import disciplina_app
from disciplinaofertada_api import disciplinaofertada_app
from solicitacaomatricula_api import solicitacaomatricula_app
import sqlite3

database = {
}

app = Flask(__name__)
app.register_blueprint(alunos_app)
app.register_blueprint(professores_app)
app.register_blueprint(coordenador_app)
app.register_blueprint(curso_app)
app.register_blueprint(disciplina_app)
app.register_blueprint(disciplinaofertada_app)
app.register_blueprint(solicitacaomatricula_app)

@app.route('/')
def all():
    con = sqlite3.connect('banco_dados')
    cur = con.cursor()
    return jsonify(cur.execute('select * from *'))

if __name__ == '__main__':
    res = input('deseja criar o bd?')
    if res == "s":
        con = sqlite3.connect("banco_dados")
        cur = con.cursor()
        cur.execute("create table professor (\
            id integer,\
            nome varchar(100),\
            matricula integer)")
        cur.execute("create table alunos (\
            id integer,\
            nome varchar(100)")
        cur.execute("create table coordenador (\
            id integer,\
            nome varchar(100)")
        cur.execute("create table cursos (\
            id integer,\
            nome varchar(100)")
        cur.execute("create table disciplinas (\
            id integer,\
            nome varchar(100),\
            data date(),\
            status varchar(20),\
            plano_ensino varchar(256),\
            carga_horaria tinyint")     
        
            
        con.commit()
        con.close()
    app.run(host='localhost', port=5000, debug=True)
