from model.disciplina import Disciplina
from infra.disciplina_log import DisciplinaLog
from infra.disciplina_db import listar as listar_db, \
    novo as novo_db


def listar():
    return listar_db()

def localiza(id_disciplina):
    for p in disciplina_db:
        if p.id_disciplina == id_disciplina:
            return p
    return None

def novo(disciplina_data):
    disciplina_db.append(Disciplina.cria(disciplina_data))
    return listar()

def remover(id_disciplina):
    index = 0
    for p in disciplina_db:
        if p.id == id_disciplina:
            log = DisciplinaLog(p)
            del disciplina_db[index]
            log.atualiza(p)
            p.finaliza_e_imprime()
            return p
        index = index + 1
    return None

def atualiza(id_disciplina, disciplina_data):
    index = 0
    for p in disciplina_db:
        if p.id_disciplina == id_disciplina:
            log = DisciplinaLog(p)
            p.atualizar(disciplina_data)
            log.atualiza(p)
            log.finaliza_e_imprime()
            return p
        index = index + 1
    return None