from model.coordenador import Coordenador
from infra.coordenador_log import CoordenadorLog
from infra.coordenador_db import listar as listar_db, \
    novo as novo_db


def listar():
    return listar_db()

def localiza(id_co):
    for p in coordenador_db:
        if p.id_co == id_co:
            return p
    return None

def novo(coordenador_data):
    coordenador_db.append(Coordenador.cria(coordenador_data))
    return listar()

def remover(id_co):
    index = 0
    for p in coordenador_db:
        if p.id == id_co:
            log = CoordenadorLog(p)
            del coordenador_db[index]
            log.atualiza(p)
            p.finaliza_e_imprime()
            return p
        index = index + 1
    return None

def atualiza(id_co, coordenador_data):
    index = 0
    for p in coordenador_db:
        if p.id == id_co:
            log = CoordenadorLog(p)
            p.atualizar(coordenador_data)
            log.atualiza(p)
            log.finaliza_e_imprime()
            return p
        index = index + 1
    return None