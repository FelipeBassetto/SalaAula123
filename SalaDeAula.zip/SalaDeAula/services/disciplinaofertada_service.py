from model.disciplinaofertada import DisciplinaOfertada
from infra.disciplinaofertada_log import DisciplinaOfertadaLog
from infra.disciplinaofertada_db import listar as listar_db, \
    novo as novo_db

def listar():
    return listar_db()

def localiza(id_disco):
    for p in disciplinaofertada_db:
        if p.id_disco == id_disco:
            return p
    return None

def novo(disco_data):
    disciplinaofertada_db.append(DisciplinaOfertada.cria(disco_data))
    return listar()

def remover(id_disco):
    index = 0
    for p in disciplinaofertada_db:
        if p.id == id_disco:
            log = DisciplinaOfertadaLog(p)
            del disciplinaofertada_db[index]
            log.atualiza(p)
            p.finaliza_e_imprime()
            return p
        index = index + 1
    return None

def atualiza(id_disco, disco_data):
    index = 0
    for p in disciplinaofertada_db:
        if p.id_disco == id_disco:
            log = DisciplinaOfertadaLog(p)
            p.atualizar(disco_data)
            log.atualiza(p)
            log.finaliza_e_imprime()
            return p
        index = index + 1
    return None