from model.professor import Professor
from infra.solocitacaomatricula_log import SolicitacaoMatriculaLog
from infra.solicitacaomaticula_db import listar as listar_db, \
    novo as novo_db


def listar():
    return listar_db

def localiza(matricula):
    for p in solicitacaomaticula_db:
        if p.matricula == matricula:
            return p
    return None

def novo(solic_data):
    solicitacaomaticula_db.append(Professor.cria(solic_data))
    return listar()

def remover(matricula):
    index = 0
    for p in solicitacaomaticula_db:
        if p.id == matricula:
            log = ProfessorLog(p)
            del solicitacaomaticula_db[index]
            log.atualiza(p)
            p.finaliza_e_imprime()
            return p
        index = index + 1
    return None

def atualiza(matricula, solic_data):
    index = 0
    for p in solicitacaomaticula_db:
        if p.matricula == matricula:
            log = ProfessorLog(p)
            p.atualizar(solic_data)
            log.atualiza(p)
            log.finaliza_e_imprime()
            return p
        index = index + 1
    return None