class Professor():
    def __init__(self, id, nome, matricula):
        self.id = id
        self.nome = nome
        self.matricula = matricula

    def atualizar(self, dados):
        try:
            self.nome = dados["nome"] if "nome" in dados else self.nome
            return self
        except Exception as e:
            print("Problema ao criar novo professor!")
            print(e)

    def __str__(self):
        return 'euu'

    def __dict__(self):
        d = dict()
        d['id'] = self.id
        d['nome'] = self.nome
        d['matricula'] = self.matricula
        return d

    @staticmethod
    def cria(dados):
        try:
            id = dados["id"]
            nome = dados["nome"]
            matricula = dados["matricula"]
            return Professor(id=id, nome=nome, matricula=matricula)
        except Exception as e:
            print("Problema ao criar novo professor!")
            print(e)

    @staticmethod
    def cria_de_tupla(dados):
        try:
            id = dados[0]
            nome = dados[1]
            matricula = dados[2]
            return Professor(id=id, nome=nome, matricula=matricula)
        except Exception as e:
            print("Problema ao criar novo professor!")
            print(e)
