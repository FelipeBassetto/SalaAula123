class SolicitacaoMatricula():
    def __init__(self, id, id_aluno, id_disco, data_solic, id_cord, status):
        self.id = id
        self.id_aluno = id_aluno
        self.id_disco = id_disco
        self.data_solic = data_solic
        self.id_cord = id_cord
        self.status = status


    def atualizar(self, dados):
        try:
            id = dados["id"]
            id_aluno = dados["id_aluno"]
            id_disco = dados["id_disco"]
            data_solic = dados["data_solic"]
            id_cord = dados["id_cord"]
            status = dados["status"]
            self.id, self.id_aluno=id_aluno,self.id_disco=id_disco,self.data_solic=data_solic,self.id_cord=id_cord,self.status=status
            return self
        except Exception as e:
            print("Problema ao criar nova solicitação de matricula!")
            print(e)

    def __dict__(self):
        d = dict()
        d['id'] = self.id
        d['id_aluno'] = self.id_aluno
        d['id_disco'] = self.id_disco
        d['data_solic'] = self.data_solic
        d['id_cord'] = self.id_cord
        d['status'] = self.status
        return d

    @staticmethod
    def cria(dados):
        try:
            id = dados["id"]
            id_aluno = dados["id_aluno"]
            id_disco = dados["id_disco"]
            data_solic = dados["data_solic"]
            id_cord = dados["id_cord"]
            status = dados["status"]
            return SolicitacaoMatricula(id=id, id_aluno=id_aluno, id_disco=id_disco, data_solic=data_solic,
             id_cord=id_cord, status=status)
        except Exception as e:
            print("Problema ao criar nova solicitação de matricula!")
            print(e)

    @staticmethod
    def cria_de_tupla(dados):
        try:
            id = dados[0]
            id_aluno = dados[1]
            id_disco = dados[2]
            data_solic = dados[3]
            id_cord = dados[4]
            status = dados[5]
            return SolicitacaoMatricula(id=id, id_aluno=id_aluno, id_disco=id_disco, data_solic=data_solic,
             id_cord=id_cord, status=status)
        except Exception as e:
            print("Problema ao criar nova solicitacao de matricula!")
            print(e)
