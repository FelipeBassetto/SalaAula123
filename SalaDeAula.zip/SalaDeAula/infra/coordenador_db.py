import sqlite3
from model.coordenador import Coordenador

def listar():
    con = sqlite3.connect('banco_dados')
    try:
        cur = con.cursor()
        cur.execute('select id, nome from coordenador')
        return [Coordenador.cria_de_tupla(el) for el in cur.fetchall()]

    finally:
        con.close()

def novo(coordenador):
    con = sqlite3.connect('banco_dados')
    try:
        cur = con.cursor()
        cur.execute("insert into coordenador(id, nome) \
            values (:id, :nome)", coordenador.__dict__())
        con.commit()
    except:
        con.rollback()
    finally:        
        con.close()
