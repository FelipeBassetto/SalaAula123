import sqlite3
from model.disciplinaofertada import disciplinaofertada

def listar():
    con = sqlite3.connect('banco_dados')
    try:
        cur = con.cursor()
        cur.execute('select id, id_disciplina, id_professor, ano, semestre, turma\
            from disciplinaofertada')
        return [aluno.cria_de_tupla(el) for el in cur.fetchall()]
    finally:
        con.close()

def novo(disciplinaofertada):
    con = sqlite3.connect('banco_dados')
    try:
        cur = con.cursor()
        cur.execute("insert into disciplinaofertada\
            (id, id_disciplina, id_professor, ano, semestre, turma) \
            values (:id, :id_disciplina, :id_professor, :ano, :semestre, :turma)",\
                disciplinaofertada.__dict__())
        con.commit()
    except:
        con.rollback()
    finally:        
        con.close()
