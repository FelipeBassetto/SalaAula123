import sqlite3
from model.SolicitacaoMatricula import SolicitacaoMatricula

def listar():
    con = sqlite3.connect('banco_dados')
    try:
        cur = con.cursor()
        cur.execute('select id, id_aluno, id_disciplina_ofertada ,id_coordenador,\
            data_solicitacao, status from SolicitacaoMatricula')
        return [SolicitacaoMatricula.cria_de_tupla(el) for el in cur.fetchall()]
    finally:
        con.close()

def novo(SolicitacaoMatricula):
    con = sqlite3.connect('banco_dados')
    try:
        cur = con.cursor()
        cur.execute("insert into SolicitacaoMatricula(id, id_aluno, \
            id_disciplina_ofertada ,id_coordenador,\
            data_solicitacao, status) \
            values (:id, :id_aluno, :id_disciplina_ofertada , :id_coordenador,\
            :data_solicitacao, :status)", SolicitacaoMatricula.__dict__())
        con.commit()
    except:
        con.rollback()
    finally:        
        con.close()
