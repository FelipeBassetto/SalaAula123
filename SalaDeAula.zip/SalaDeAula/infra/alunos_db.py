import sqlite3
from model.alunos import Aluno

def listar():
    con = sqlite3.connect('banco_dados')
    try:
        cur = con.cursor()
        cur.execute('select id, nome from alunos')
        return [Aluno.cria_de_tupla(el) for el in cur.fetchall()]
    finally:
        con.close()

def novo(alunos):
    con = sqlite3.connect('banco_dados')
    try:
        cur = con.cursor()
        cur.execute("insert into alunos(id, nome) \
            values (:id, :nome)", alunos.__dict__())
        con.commit()
    except:
        con.rollback()
    finally:        
        con.close()
