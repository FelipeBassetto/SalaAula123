import sqlite3
from model.disciplina import disciplina

def listar():
    con = sqlite3.connect('banco_dados')
    try:
        cur = con.cursor()
        cur.execute('select id, nome, data, status, plano_ensino, carga_horaria, id_coordenador\
            from disciplina')
        return [disciplina.cria_de_tupla(el) for el in cur.fetchall()]
    finally:
        con.close()

def novo(disciplina):
    con = sqlite3.connect('banco_dados')
    try:
        cur = con.cursor()
        cur.execute("insert into disciplina(id, nome, data, status\
            plano_ensino, carga_horaria, id_coordenador) \
            values (:id, :nome, :data, :status\
            :plano_ensino, :carga_horaria, :id_coordenador)", disciplina.__dict__())
        con.commit()
    except:
        con.rollback()
    finally:        
        con.close()
