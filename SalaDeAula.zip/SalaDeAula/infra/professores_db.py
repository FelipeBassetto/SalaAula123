import sqlite3
from model.professor import Professor

def listar():
    con = sqlite3.connect('banco_dados')
    try:
        cur = con.cursor()
        cur.execute('select id, nome, matricula from professor')
        return [Professor.cria_de_tupla(el) for el in cur.fetchall()]
    finally:
        con.close()

def novo(professor):
    con = sqlite3.connect('banco_dados')
    try:
        cur = con.cursor()
        cur.execute("insert into professor(id, nome, matricula) \
            values (:id, :nome, :matricula)", professor.__dict__())
        con.commit()
    except:
        con.rollback()
    finally:        
        con.close()
