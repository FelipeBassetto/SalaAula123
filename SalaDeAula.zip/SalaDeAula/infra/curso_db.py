import sqlite3
from model.curso import curso

def listar():
    con = sqlite3.connect('banco_dados')
    try:
        cur = con.cursor()
        cur.execute('select id, nome from curso')
        return [curso.cria_de_tupla(el) for el in cur.fetchall()]
    finally:
        con.close()

def novo(curso):
    con = sqlite3.connect('banco_dados')
    try:
        cur = con.cursor()
        cur.execute("insert into curso(id, nome) \
            values (:id, :nome)", curso.__dict__())
        con.commit()
    except:
        con.rollback()
    finally:        
        con.close()
