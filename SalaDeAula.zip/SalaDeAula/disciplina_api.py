from flask import Blueprint, jsonify, request
from services.disciplina_service import listar as service_listar, \
    localiza as service_localiza, \
    novo as service_novo, \
    remover as service_remover, \
    atualiza as service_atualiza

disciplina_app = Blueprint('disciplina_app', __name__, template_folder='templates')

@disciplina_app.route('/disciplinas', methods=['GET'])
def listar():
    disc_list = service_listar()
    return jsonify(list(map(lambda disc: disc.__dict__(), disc_list)))

@disciplina_app.route('/disciplinas/<int:id_disciplina>', methods=['GET'])
def localiza(id_disciplina):
    p = service_localiza(id_disciplina)
    if(p != None):
        return jsonify(p.__dict__())
    return '', 404

@disciplina_app.route('/disciplinas', methods=['POST'])
def novo():
    nova_disciplina = request.get_json()
    disc_list = service_novo(nova_disciplina)
    print('exibe com list comprehensions')
    return jsonify([disc.__dict__() for disc in disc_list])


@disciplina_app.route('/disciplinas/<int:id_disciplina>', methods=['DELETE'])
def remover(id_disciplina):
    removido = service_remover(id_disciplina)
    if removido != None:
        return jsonify(removido.__dict__())
    return '', 404

@disciplina_app.route('/disciplinas/<int:id_disciplina>', methods=['PUT'])
def atualiza(id_disciplina):
    disciplina_data = request.get_json()
    removido = service_atualiza(id_disciplina, disciplina_data)
    if removido != None:
        return jsonify(removido.__dict__())
    return '', 404