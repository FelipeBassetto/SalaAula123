from flask import Blueprint, jsonify, request
from services.coordenadores_service import listar as service_listar, \
    localiza as service_localiza, \
    novo as service_novo, \
    remover as service_remover, \
    atualiza as service_atualiza

coordenador_app = Blueprint('coordenador_app', __name__, template_folder='templates')

@coordenador_app.route('/coordenador', methods=['GET'])
def listar():
    co_list = service_listar()
    return jsonify(list(map(lambda co: co.__dict__(), co_list)))

@coordenador_app.route('/coordenador/<int:id_coordenador>', methods=['GET'])
def localiza(id_coordenador):
    co = service_localiza(id_coordenador)
    if(co != None):
        return jsonify(co.__dict__())
    return '', 404

@coordenador_app.route('/coordenador', methods=['POST'])
def novo():
    novo_coordenador = request.get_json()
    co_list = service_novo(novo_coordenador)
    print('exibe com list comprehensions')
    return jsonify([co.__dict__() for co in co_list])

@coordenador_app.route('/coordenador/<int:id_coordenador>', methods=['DELETE'])
def remover(id_coordenador):
    removido = service_remover(id_coordenador)
    if removido != None:
        return jsonify(removido.__dict__())
    return '', 404


@coordenador_app.route('/coordenador/<int:id_coordenador>', methods=['PUT'])
def atualiza(id_coordenador):
    coordenador_data = request.get_json()
    removido = service_atualiza(id_coordenador, coordenador_data)
    if removido != None:
        return jsonify(removido.__dict__())
    return '', 404