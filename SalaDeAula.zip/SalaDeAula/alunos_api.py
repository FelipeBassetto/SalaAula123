from flask import Blueprint, jsonify, request
from services.alunos_service import listar as service_listar, \
    localiza as service_localiza, \
    novo as service_novo, \
    remover as service_remover, \
    atualiza as service_atualiza
alunos_app = Blueprint('alunos_app', __name__, template_folder='templates')

@alunos_app.route('/alunos', methods=['GET'])
def listar():
    al_list = service_listar() 
    return jsonify(list(map(lambda pr: pr.__dict__(), al_list)))

@alunos_app.route('/alunos/<int:id_aluno>', methods=['GET'])
def localiza(id_aluno):
    a = service_listar(id_aluno)
    if(a != None):
        return jsonify(p.__dict__())
    return '', 404

@alunos_app.route('/alunos', methods=['POST'])
def novo():
    novo_aluno = request.get_json()
    pr_list = service_novo(novo_aluno)
    print('exibe com list comprehensions')
    return jsonify([al.__dict__() for al in pr_list])

@alunos_app.route('/alunos/<int:id_aluno>', methods=['DELETE'])
def remover(id_aluno):
    removido = service_remover(id_aluno)
    if removido != None:
        return jsonify(removido.__dict__())
    return '', 404

@alunos_app.route('/alunos/<int:id_aluno>', methods=['PUT'])
def atualiza(id_aluno):
    aluno_data = request.get_json()
    removido = service_atualiza(id_aluno, aluno_data)
    if removido != None:
        return jsonify(removido.__dict__())
    return '', 404